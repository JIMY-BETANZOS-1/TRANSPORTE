const express = require('express');
const router = express.Router();

const { procesarPago, consultarPago, confirmarPago } = require('../controllers/pagosController');
const { verificarToken } = require('../middlewares/auth');

router.post('/', procesarPago);
router.post('/confirmar', confirmarPago);
router.get('/:reserva_id', verificarToken, consultarPago);

module.exports = router;
